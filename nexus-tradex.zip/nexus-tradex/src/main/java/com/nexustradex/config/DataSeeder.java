package com.nexustradex.config;

import com.nexustradex.model.Trade;
import com.nexustradex.model.TradingAgent;
import com.nexustradex.repository.TradeRepository;
import com.nexustradex.repository.TradingAgentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Configuration
public class DataSeeder {

    @Bean
    CommandLineRunner seedData(TradingAgentRepository agentRepo, TradeRepository tradeRepo) {
        return args -> {

            TradingAgent andrei = agentRepo.save(TradingAgent.builder()
                    .name("Andrei's Agent")
                    .apiKey("key-andrei-001")
                    .bankroll(new BigDecimal("620.00"))
                    .initialDeposit(new BigDecimal("500.00"))
                    .status(TradingAgent.AgentStatus.ACTIVE)
                    .requiresApproval(false)
                    .build());

            tradeRepo.save(trade(andrei, "BTC/USD", Trade.TradeType.BUY, Trade.MarketType.CRYPTO,
                    "500", "61000", "63500", "41.00", Trade.TradeStatus.CLOSED,
                    "BTC showing bullish momentum", 78));
            tradeRepo.save(trade(andrei, "NVDA", Trade.TradeType.BUY, Trade.MarketType.STOCK,
                    "3", "850", "920", "210.00", Trade.TradeStatus.CLOSED,
                    "Earnings beat expected", 85));
            tradeRepo.save(trade(andrei, "BTC/USD", Trade.TradeType.SELL, Trade.MarketType.CRYPTO,
                    "200", "63000", "61500", "-30.00", Trade.TradeStatus.CLOSED,
                    "Overbought RSI signal", 60));
            tradeRepo.save(trade(andrei, "ETH/USD", Trade.TradeType.BUY, Trade.MarketType.CRYPTO,
                    "300", "3200", "3500", "28.00", Trade.TradeStatus.CLOSED,
                    "ETH/BTC ratio improving", 72));
            tradeRepo.save(trade(andrei, "Polymarket:Election2026", Trade.TradeType.BUY, Trade.MarketType.POLYMARKET,
                    "100", "0.45", "0.72", "29.40", Trade.TradeStatus.CLOSED,
                    "Polling data shifted favorably", 68));

            TradingAgent marin = agentRepo.save(TradingAgent.builder()
                    .name("Marin's Agent")
                    .apiKey("key-marin-002")
                    .bankroll(new BigDecimal("350.00"))
                    .initialDeposit(new BigDecimal("300.00"))
                    .status(TradingAgent.AgentStatus.ACTIVE)
                    .requiresApproval(true)
                    .build());

            tradeRepo.save(trade(marin, "BTC/USD", Trade.TradeType.BUY, Trade.MarketType.CRYPTO,
                    "200", "62000", null, null, Trade.TradeStatus.PENDING_APPROVAL,
                    "BTC showing upward trend with 82% confidence based on volume analysis", 82));
            tradeRepo.save(trade(marin, "Polymarket:WorldCup2026", Trade.TradeType.BUY, Trade.MarketType.POLYMARKET,
                    "50", "0.30", null, null, Trade.TradeStatus.PENDING_APPROVAL,
                    "Recent fixture results suggest underdog is gaining momentum", 67));

            System.out.println("=== Nexus Tradex: Sample data seeded ===");
            System.out.println("Dashboard (Andrei): http://localhost:8080/api/dashboard/1");
            System.out.println("Dashboard (Marin):  http://localhost:8080/api/dashboard/2");
        };
    }

    private Trade trade(TradingAgent agent, String market, Trade.TradeType type,
                        Trade.MarketType mkt, String amount, String entry, String exit,
                        String pnl, Trade.TradeStatus status, String aiReason, int confidence) {
        return Trade.builder()
                .agent(agent)
                .market(market)
                .type(type)
                .marketType(mkt)
                .amount(new BigDecimal(amount))
                .entryPrice(new BigDecimal(entry))
                .exitPrice(exit != null ? new BigDecimal(exit) : null)
                .profitLoss(pnl != null ? new BigDecimal(pnl) : null)
                .status(status)
                .aiReason(aiReason)
                .aiConfidence(confidence)
                .createdAt(LocalDateTime.now())
                .executedAt(status == Trade.TradeStatus.CLOSED ? LocalDateTime.now().minusDays(1) : null)
                .closedAt(status == Trade.TradeStatus.CLOSED ? LocalDateTime.now() : null)
                .build();
    }
}
