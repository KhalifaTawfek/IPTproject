package com.nexustradex.config;

import com.nexustradex.model.Trade;
import com.nexustradex.model.TradingAgent;
import com.nexustradex.model.User;
import com.nexustradex.repository.TradeRepository;
import com.nexustradex.repository.TradingAgentRepository;
import com.nexustradex.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Configuration
public class DataSeeder {

    @Bean
    @Transactional
    public CommandLineRunner seedData(TradingAgentRepository agentRepo,
                                      TradeRepository tradeRepo,
                                      UserRepository userRepo,
                                      PasswordEncoder passwordEncoder) {
        return args -> {

            // ===== ADMIN =====
            TradingAgent adminAgent = agentRepo.save(TradingAgent.builder()
                    .name("Admin Monitor")
                    .apiKey("key-admin-000")
                    .bankroll(new BigDecimal("10000.00"))
                    .initialDeposit(new BigDecimal("10000.00"))
                    .status(TradingAgent.AgentStatus.ACTIVE)
                    .requiresApproval(false)
                    .build());

            User admin = new User();
            admin.setUsername("admin");
            admin.setEmail("admin@nexustradex.com");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRole(User.Role.ADMIN);
            admin.setEnabled(true);
            admin.setAgent(adminAgent);
            userRepo.save(admin);

            // ===== ALEX =====
            TradingAgent alexAgent = agentRepo.save(TradingAgent.builder()
                    .name("AlphaBot-7 (Alex)")
                    .apiKey("sk-alex-bt7-prod-2024")
                    .bankroll(new BigDecimal("1247.50"))
                    .initialDeposit(new BigDecimal("1000.00"))
                    .status(TradingAgent.AgentStatus.ACTIVE)
                    .requiresApproval(false)
                    .build());

            User alex = new User();
            alex.setUsername("alex");
            alex.setEmail("alex@example.com");
            alex.setPassword(passwordEncoder.encode("password123"));
            alex.setRole(User.Role.USER);
            alex.setEnabled(true);
            alex.setAgent(alexAgent);
            userRepo.save(alex);

            tradeRepo.save(trade(alexAgent, "BTC/USD", Trade.TradeType.BUY, Trade.MarketType.CRYPTO,
                    "500", "61200", "67800", "53.93", Trade.TradeStatus.CLOSED,
                    "RSI oversold + MACD bullish", 88,
                    minus(30), minus(28), minus(20)));

            tradeRepo.save(trade(alexAgent, "NVDA", Trade.TradeType.BUY, Trade.MarketType.STOCK,
                    "2", "850.00", "920.00", "140.00", Trade.TradeStatus.CLOSED,
                    "Strong earnings", 91,
                    minus(25), minus(24), minus(18)));

            // ===== SARA =====
            TradingAgent saraAgent = agentRepo.save(TradingAgent.builder()
                    .name("CautiousAI (Sara)")
                    .apiKey("sk-sara-cautious-v2")
                    .bankroll(new BigDecimal("820.00"))
                    .initialDeposit(new BigDecimal("800.00"))
                    .status(TradingAgent.AgentStatus.ACTIVE)
                    .requiresApproval(true)
                    .build());

            User sara = new User();
            sara.setUsername("sara");
            sara.setEmail("sara@example.com");
            sara.setPassword(passwordEncoder.encode("password123"));
            sara.setRole(User.Role.USER);
            sara.setEnabled(true);
            sara.setAgent(saraAgent);
            userRepo.save(sara);

            tradeRepo.save(trade(saraAgent, "BTC/USD", Trade.TradeType.BUY, Trade.MarketType.CRYPTO,
                    "200", "62000", "65800", "12.26", Trade.TradeStatus.CLOSED,
                    "Conservative trade", 76,
                    minus(20), minus(19), minus(5)));

            // ===== MARCO =====
            TradingAgent marcoAgent = agentRepo.save(TradingAgent.builder()
                    .name("Degen-99 (Marco)")
                    .apiKey("sk-marco-degen99")
                    .bankroll(new BigDecimal("340.00"))
                    .initialDeposit(new BigDecimal("500.00"))
                    .status(TradingAgent.AgentStatus.PAUSED)
                    .requiresApproval(false)
                    .build());

            User marco = new User();
            marco.setUsername("marco");
            marco.setEmail("marco@example.com");
            marco.setPassword(passwordEncoder.encode("password123"));
            marco.setRole(User.Role.USER);
            marco.setEnabled(true);
            marco.setAgent(marcoAgent);
            userRepo.save(marco);

            tradeRepo.save(trade(marcoAgent, "DOGE/USD", Trade.TradeType.BUY, Trade.MarketType.CRYPTO,
                    "300", "0.18", "0.12", "-33.33", Trade.TradeStatus.CLOSED,
                    "High risk meme trade", 44,
                    minus(28), minus(27), minus(15)));

            System.out.println("✅ Data seeded successfully");
        };
    }

    private Trade trade(TradingAgent agent, String market, Trade.TradeType type,
                        Trade.MarketType mkt, String amount, String entry, String exit,
                        String pnl, Trade.TradeStatus status, String aiReason, int confidence,
                        LocalDateTime created, LocalDateTime executed, LocalDateTime closed) {
        return Trade.builder()
                .agent(agent)
                .market(market)
                .type(type)
                .marketType(mkt)
                .amount(new BigDecimal(amount))
                .entryPrice(new BigDecimal(entry))
                .exitPrice(exit != null ? new BigDecimal(exit) : null)
                .profitLoss(pnl != null ? new BigDecimal(pnl) : null)
                .status(status)
                .aiReason(aiReason)
                .aiConfidence(confidence)
                .createdAt(created)
                .executedAt(executed)
                .closedAt(closed)
                .build();
    }

    private LocalDateTime minus(int days) {
        return LocalDateTime.now().minusDays(days);
    }
}
