@REM Maven Wrapper Script for Windows
@REM ----------------------------------------------------------------------------

@IF "%JAVA_HOME%" == "" (
  SET JAVACMD=java
) ELSE (
  SET JAVACMD="%JAVA_HOME%\bin\java"
)

SET WRAPPER_JAR=.mvn\wrapper\maven-wrapper.jar
SET WRAPPER_PROPERTIES=.mvn\wrapper\maven-wrapper.properties

@IF NOT EXIST %WRAPPER_JAR% (
  echo Downloading maven-wrapper.jar...
  powershell -Command "Invoke-WebRequest -Uri 'https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.2.0/maven-wrapper-3.2.0.jar' -OutFile '%WRAPPER_JAR%'"
)

%JAVACMD% -jar %WRAPPER_JAR% %*
