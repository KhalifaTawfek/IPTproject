# Nexus Tradex — Spring Boot Backend

AI Trading Agent Dashboard for Polymarket & Stocks.

## Tech Stack
- **Java 17** + **Spring Boot 3.2**
- **Spring Data JPA** (H2 for dev, PostgreSQL for production)
- **Spring Security** (disabled in dev for simplicity)
- **Lombok**

## Project Structure

```
src/main/java/com/nexustradex/
├── NexusTradexApplication.java     # Entry point
├── config/
│   ├── DataSeeder.java             # Sample data (Andrei & Marin personas)
│   └── SecurityConfig.java         # Auth config
├── controller/
│   └── DashboardController.java    # REST API endpoints
├── dto/
│   ├── DashboardSummaryDTO.java    # Dashboard response
│   └── TradeDTO.java               # Trade response
├── model/
│   ├── Trade.java                  # Trade entity
│   └── TradingAgent.java           # Agent entity
├── repository/
│   ├── TradeRepository.java
│   └── TradingAgentRepository.java
└── service/
    └── TradeService.java           # Business logic
```

## Running the Project

```bash
./mvnw spring-boot:run
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/dashboard/{agentId}` | Full dashboard: profit, win rate, trades, AI suggestions |
| GET | `/api/agents/{agentId}/trades` | All trades for an agent |
| POST | `/api/trades/{tradeId}/approve` | Approve AI trade suggestion (Marin) |
| POST | `/api/trades/{tradeId}/reject` | Reject AI trade suggestion |

## Quick Test URLs (after startup)

- **H2 Console**: http://localhost:8080/h2-console (JDBC URL: `jdbc:h2:mem:nexustradexdb`)
- **Andrei's Dashboard**: http://localhost:8080/api/dashboard/1
- **Marin's Dashboard**: http://localhost:8080/api/dashboard/2
- **Marin's Trades**: http://localhost:8080/api/agents/2/trades

## Production Switch

In `application.properties`, comment out H2 settings and use:
```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/nexustradex
spring.datasource.username=your_user
spring.datasource.password=your_password
spring.jpa.hibernate.ddl-auto=update
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQLDialect
```

## User Stories Covered

| Persona | Feature | Endpoint |
|---------|---------|----------|
| Andrei (Beginner) | See profit, bankroll, win rate instantly | `GET /api/dashboard/1` |
| Maria (Casual Trader) | View trade history & performance | `GET /api/agents/1/trades` |
| Marin (AI User) | Approve/reject AI suggestions | `POST /api/trades/{id}/approve` |
